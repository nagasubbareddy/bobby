package com.niit.wheelsbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.fourwheels.dao.ProductDAO;
import com.niit.fourwheels.model.Product;

public class ProductTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.fourwheels");
		context.refresh();
		
		
	   ProductDAO productDAO = 	(ProductDAO) context.getBean("productDAO");
	   
	   Product product = 	(Product) context.getBean("product");
	   product.setId("PD120");
	   product.setName("PDName120");
	   product.setPrice(10000);
	   product.setDescription("PDDesc120");
	   
	   
	   productDAO.saveOrUpdate(product);
	   
	   
	   
	   
	  if(   productDAO.get("sdfsf") ==null)
	  {
		  System.out.println("Product does not exist");
	  }
	  else
	  {
		  System.out.println("Product exist .. the details are ..");
		  System.out.println();
	  }
		
		
		
	}

}
