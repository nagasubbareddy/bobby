package com.niit.wheelsbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.fourwheels.dao.UserDAO;
import com.niit.fourwheels.model.User;

public class UserTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.wheelsbackend");
		context.refresh();

		UserDAO userDAO = (UserDAO) context.getBean("UserDAO");

		User user = (User) context.getBean("user");
		user.setId("nsr2");
		user.setName("naveen");
		user.setAddress("nlg");
		user.setMail("naveen@gmail.com");
		user.setMobile(950543214);
		user.setPassword("123456");

		userDAO.saveOrUpdate(user);

		
	}

}
