package com.niit.fourwheels.dao;

public class CategoryDAOImpl {

}
