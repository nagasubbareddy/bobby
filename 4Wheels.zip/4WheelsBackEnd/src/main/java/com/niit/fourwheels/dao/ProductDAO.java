package com.niit.fourwheels.dao;

public class ProductDAO {

}
