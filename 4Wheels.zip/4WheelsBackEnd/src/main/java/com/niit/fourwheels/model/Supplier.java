package com.niit.fourwheels.model;

public class Supplier {

}
