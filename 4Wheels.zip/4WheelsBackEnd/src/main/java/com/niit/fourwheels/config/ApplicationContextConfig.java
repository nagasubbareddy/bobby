package com.niit.fourwheels.config;

public class ApplicationContextConfig {

}
