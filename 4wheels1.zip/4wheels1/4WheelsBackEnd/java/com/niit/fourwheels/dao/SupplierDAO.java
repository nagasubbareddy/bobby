package com.niit.fourwheels.dao;

import java.util.List;

import com.niit.fourwheels.model.Supplier;

public interface SupplierDAO {

	
	public List<Supplier> list();
	
	public Supplier get(String id);
	
	public void saveOrUpdate(Supplier supplier);
	
	public void delete(String id);
}
