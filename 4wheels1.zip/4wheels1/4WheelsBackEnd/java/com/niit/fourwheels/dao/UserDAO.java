package com.niit.fourwheels.dao;

import java.util.List;

import org.h2.engine.User;



public interface UserDAO {
	
	public List<User> list();
	
	public User get(String id);
	
	public void saveOrUpdate(User user);
	
	public void delete(String id);

}
