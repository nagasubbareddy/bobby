package com.niit.wheelsbackend;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.fourwheels.dao.CategoryDAO;
import com.niit.fourwheels.model.Category;

public class CategoryJUnitTest {

	@Autowired
	Category category;
	@Autowired
	CategoryDAO categoryDAO;
	
	static AnnotationConfigApplicationContext config;
	
	@Before
	public void initial()
	{
		config= new AnnotationConfigApplicationContext();
		config.scan("com.niit");
		config.refresh();
		category= (Category) config.getBean("category");
		categoryDAO = (CategoryDAO) config.getBean("categoryDAO");
		
	}
	@Test
	public void CategorysizeTest()
	{
	int size=categoryDAO.list().size();
	assertEquals("category size is ", 3,size);
	}
	
	@Test
	public void CategoryGetTest()
	{
		category = categoryDAO.get("CG120");
		String id = category.getId();
		assertEquals("category id is", "CG120",id);
	}
	@Test
	public void CategorydeleteTest()
	{
		categoryDAO.delete("CG140");
		
	}
	@Test
	public void CategorySaveorupdateTest()
	{
		category.setId("CG143");
		category.setName("CGName120");
		category.setDescription("CGDesc120");
		categoryDAO.saveOrUpdate(category);
		
	}
		
	

}
