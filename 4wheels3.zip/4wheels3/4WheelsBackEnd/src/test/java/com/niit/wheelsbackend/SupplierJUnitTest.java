package com.niit.wheelsbackend;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.fourwheels.dao.SupplierDAO;
import com.niit.fourwheels.model.Supplier;

public class SupplierJUnitTest {

	@Autowired
	Supplier supplier;
	@Autowired
	SupplierDAO supplierDAO;
	
	static AnnotationConfigApplicationContext config;
	
	@Before
	public void initial()
	{
		config= new AnnotationConfigApplicationContext();
		config.scan("com.niit");
		config.refresh();
		supplier= (Supplier) config.getBean("supplier");
		supplierDAO = (SupplierDAO) config.getBean("supplierDAO");
		
	}
	@Test
	public void SuppliersizeTest()
	{
	int size=supplierDAO.list().size();
	assertEquals("supplier size is ", 3,size);
	}
	
	@Test
	public void SupplierGetTest()
	{
		supplier = supplierDAO.get("SR120");
		String id = supplier.getId();
		assertEquals("supplier id is", "SR120",id);
	}
	@Test
	public void SupplierdeleteTest()
	{
		supplierDAO.delete("SR140");
		
	}
	@Test
	public void SupplierSaveorupdateTest()
	{
		supplier.setId("SR143");
		supplier.setName("SRName120");
		supplier.setAddress("SRAddr120");
		supplierDAO.saveOrUpdate(supplier);
		
	}
		
	

}
