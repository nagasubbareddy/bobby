package com.niit.wheelsbackend;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.fourwheels.dao.UserDAO;
import com.niit.fourwheels.model.User;

public class UserJUnitTest {

	@Autowired
	User user;
	@Autowired
	UserDAO userDAO;
	
	static AnnotationConfigApplicationContext config;
	
	@Before
	public void initial()
	{
		config= new AnnotationConfigApplicationContext();
		config.scan("com.niit");
		config.refresh();
		user= (User) config.getBean("user");
		userDAO = (UserDAO) config.getBean("userDAO");
		
	}
	@Test
	public void UsersizeTest()
	{
	int size=userDAO.list().size();
	assertEquals("user size is ", 3,size);
	}
	
	@Test
	public void UserGetTest()
	{
		user = userDAO.get("UR120");
		String id = user.getId();
		assertEquals("user id is", "UR120",id);
	}
	@Test
	public void UserdeleteTest()
	{
		userDAO.delete("UR140");
		
	}
	@Test
	public void UserSaveorupdateTest()
	{
		user.setId("UR143");
		user.setName("URName120");
		user.setPassword("URPassword120");
		user.setMail("USMail120");
		user.setMobile(1234656);
		user.setAddress("URAddress120");
		userDAO.saveOrUpdate(user);
		
	}
		
	

}
