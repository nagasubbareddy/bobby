package com.niit.homecontroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	ModelAndView h;
	@RequestMapping("/")
	public ModelAndView homeData()
	{
		h= new ModelAndView("home");
		return h;
	}
	
}
